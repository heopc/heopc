import { useState, useEffect } from "react";

type Movie = {
  id: string;
  title: string;
  img: string;
  video: string;
};

type User = {
  username: string;
  password: string;
};

export default function App() {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [movie, setMovie] = useState<Movie | null>(null);

  const [user, setUser] = useState<string | null>(null);
  const [admin, setAdmin] = useState(false);

  const [authMode, setAuthMode] = useState<"login" | "register">("login");
  const [auth, setAuth] = useState({ username: "", password: "" });

  const [search, setSearch] = useState("");
  const [favorites, setFavorites] = useState<Movie[]>([]);

  const [page, setPage] = useState<"home" | "fav">("home");

  const [form, setForm] = useState({
    title: "",
    img: "",
    video: "",
  });
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [adminAuth, setAdminAuth] = useState({
    username: "",
    password: "",
  });

  // LOAD DATA
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("movies") || "[]");
    const fav = JSON.parse(localStorage.getItem("fav") || "[]");
    const savedUser = localStorage.getItem("user");
    const users = JSON.parse(localStorage.getItem("users") || "[]");
  
    setMovies(data);
    setFavorites(fav);
  
    if (savedUser && users.some(u => u.username === savedUser)) {
      setUser(savedUser);
    }
  }, []);
  
  const saveMovies = (data: Movie[]) => {
    setMovies(data);
    localStorage.setItem("movies", JSON.stringify(data));
  };

  const saveFav = (data: Movie[]) => {
    setFavorites(data);
    localStorage.setItem("fav", JSON.stringify(data));
  };

  const loginAdmin = () => {
    setShowAdminLogin(true);
  };

  const register = () => {
    const users: User[] = JSON.parse(localStorage.getItem("users") || "[]");
  
    if (!auth.username || !auth.password)
      return alert("Nhập đầy đủ!");
  
    const exists = users.some(
      (u) => u.username === auth.username
    );
  
    if (exists) {
      return alert("User đã tồn tại!");
    }
  
    const newUser = {
      username: auth.username,
      password: auth.password,
    };
  
    const updatedUsers = [...users, newUser];
  
    localStorage.setItem("users", JSON.stringify(updatedUsers));
  
    alert("Đăng ký thành công!");
    setAuthMode("login");
    setAuth({ username: "", password: "" }); // reset form
  };

  const login = () => {
    const users: User[] = JSON.parse(localStorage.getItem("users") || "[]");
  
    const found = users.find(
      (u) =>
        u.username === auth.username &&
        u.password === auth.password
    );
  
    if (found) {
      setUser(found.username);
      localStorage.setItem("user", found.username);
      setAuth({ username: "", password: "" });
    } else {
      alert("Sai tài khoản!");
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("user");
  };

  const addMovie = () => {
    const newMovie: Movie = {
      id: crypto.randomUUID(),
      ...form,
    };

    saveMovies([...movies, newMovie]);
    setForm({ title: "", img: "", video: "" });
  };

  const deleteMovie = (id: string) => {
    saveMovies(movies.filter((m) => m.id !== id));
  };

  const toggleFav = (m: Movie) => {
    if (favorites.find((f) => f.id === m.id)) {
      saveFav(favorites.filter((f) => f.id !== m.id));
    } else {
      saveFav([...favorites, m]);
    }
  };

  const filtered = movies.filter((m) =>
    m.title.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div style={{ background: "#141414", color: "white", minHeight: "100vh" }}>

      {/* ✅ ADMIN LOGIN MODAL (ĐẸP) */}
      {showAdminLogin && (
        <div style={adminModal.overlay}>
          <div style={adminModal.box}>
            <h2 style={{ marginBottom: 15 }}>🛠 Admin Login</h2>

            <input
              style={adminModal.input}
              placeholder="Username"
              onChange={(e) =>
                setAdminAuth({ ...adminAuth, username: e.target.value })
              }
            />

            <input
              style={adminModal.input}
              type="password"
              placeholder="Password"
              onChange={(e) =>
                setAdminAuth({ ...adminAuth, password: e.target.value })
              }
            />

            <button
              style={adminModal.loginBtn}
              onClick={() => {
                if (
                  adminAuth.username === "Heopc" &&
                  adminAuth.password === "Theanh123@"
                ) {
                  setAdmin(true);
                  setShowAdminLogin(false);
                } else {
                  alert("Sai!");
                }
              }}
            >
              Login Admin
            </button>

            <button
              style={adminModal.cancelBtn}
              onClick={() => setShowAdminLogin(false)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      {/* AUTH */}
      {!user ? (
        <div style={authStyle.container}>
          <div style={authStyle.box}>
            <h2>
              {authMode === "login" ? "🔐 Đăng nhập" : "🆕 Đăng ký"}
            </h2>

            <input
              style={authStyle.input}
              placeholder="Username"
              onChange={(e) =>
                setAuth({ ...auth, username: e.target.value })
              }
            />

            <input
              style={authStyle.input}
              type="password"
              placeholder="Password"
              onChange={(e) =>
                setAuth({ ...auth, password: e.target.value })
              }
            />

            {authMode === "login" ? (
              <button style={authStyle.button} onClick={login}>
                Login
              </button>
            ) : (
              <button style={authStyle.button} onClick={register}>
                Register
              </button>
            )}

            <p style={{ marginTop: 10 }}>
              <span
                style={{ color: "cyan", cursor: "pointer" }}
                onClick={() =>
                  setAuthMode(authMode === "login" ? "register" : "login")
                }
              >
                {authMode === "login" ? "Đăng ký" : "Đăng nhập"}
              </span>
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* HEADER */}
          <div style={header}>
            <img
              src="https://www.image2url.com/r2/default/images/1776158656949-693fbd02-9d51-4750-94f1-9c6f6a64adb0.png"
              style={{ height: 70 }}
            />

            <input
              placeholder="Search..."
              onChange={(e) => setSearch(e.target.value)}
              style={{ marginLeft: 20, padding: 8 }}
            />

            {/* MENU */}
            <div style={navStyle}>
  <button
    onClick={() => setPage("home")}
    style={{
      ...navBtn,
      background: page === "home" ? "red" : "#222",
      color: page === "home" ? "white" : "#aaa",
      boxShadow: page === "home" ? "0 0 10px red" : "none",
    }}
  >
    🎬 Danh sách phim
  </button>

  <button
    onClick={() => setPage("fav")}
    style={{
      ...navBtn,
      background: page === "fav" ? "hotpink" : "#222",
      color: page === "fav" ? "white" : "#aaa",
      boxShadow: page === "fav" ? "0 0 10px hotpink" : "none",
    }}
  >
    ❤️ Yêu thích
  </button>
</div>

            <span style={{ marginLeft: "auto" }}>👤 {user}</span>

            <button
  onClick={logout}
  style={{
    marginLeft: 10,
    padding: "8px 14px",
    borderRadius: 10,
    border: "none",
    cursor: "pointer",
    fontWeight: "bold",
    background: "linear-gradient(90deg, #ff4d4d, #b30000)",
    color: "white",
    boxShadow: "0 0 12px rgba(255,0,0,0.6)",
    transition: "0.2s",
  }}
>
  🚪 Logout
</button>

{admin ? (
  <button
    onClick={() => setAdmin(false)}
    style={{
      marginLeft: 10,
      padding: "8px 14px",
      borderRadius: 10,
      border: "none",
      cursor: "pointer",
      fontWeight: "bold",
      background: "linear-gradient(90deg, #555, #222)",
      color: "#fff",
    }}
  >
    🚪 Thoát Admin
  </button>
) : (
  <button
    onClick={loginAdmin}
    style={{
      marginLeft: 10,
      padding: "8px 14px",
      borderRadius: 10,
      border: "none",
      cursor: "pointer",
      fontWeight: "bold",
      background: "linear-gradient(90deg, #333, #111)",
      color: "#fff",
    }}
  >
    🛠 Admin
  </button>
)}
          </div>

          {/* ADMIN */}
          {admin && (
  <div style={uploadStyle.container}>
    <h2 style={uploadStyle.title}>🎬 Upload phim</h2>

    <input
      style={uploadStyle.input}
      placeholder="Tên phim"
      onChange={(e) =>
        setForm({ ...form, title: e.target.value })
      }
    />

    <input
      style={uploadStyle.input}
      placeholder="Link ảnh"
      onChange={(e) =>
        setForm({ ...form, img: e.target.value })
      }
    />

    <input
      style={uploadStyle.input}
      placeholder="Link video"
      onChange={(e) =>
        setForm({ ...form, video: e.target.value })
      }
    />

    <button style={uploadStyle.button} onClick={addMovie}>
      ➕ Thêm phim
    </button>
  </div>
)}

          {/* LIST HOME */}
          {!movie && page === "home" && (
            <>
              <h2 style={{ padding: 20, color: "#fff" }}>🎬 Danh sách phim</h2>

              <div style={grid}>
                {filtered.map((m) => (
                  <div key={m.id}>
                    <img
                      src={m.img}
                      width="100%"
                      onClick={() => setMovie(m)}
                    />
                    <p>{m.title}</p>

                    <button onClick={() => toggleFav(m)}>
                      {favorites.find((f) => f.id === m.id)
                        ? "💔 Bỏ thích"
                        : "❤️ Yêu thích"}
                    </button>

                    {admin && (
                      <button onClick={() => deleteMovie(m.id)}>
                        🗑 Xóa
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </>
          )}

          {/* FAVORITES PAGE */}
          {!movie && page === "fav" && (
            <>
              <h2 style={{ padding: 20, color: "#fff" }}>❤️ Yêu thích</h2>

              {favorites.length === 0 ? (
                <p style={{ padding: 20 }}>Chưa có phim yêu thích</p>
              ) : (
                <div style={grid}>
                  {favorites.map((m) => (
                    <div key={m.id} onClick={() => setMovie(m)}>
                      <img src={m.img} width="100%" />
                      <p>{m.title}</p>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {/* VIDEO */}
          {movie && (
            <div style={{ padding: 20 }}>
              <button onClick={() => setMovie(null)}>⬅ Back</button>
              <h2>{movie.title}</h2>

              <video controls width="100%">
                <source src={movie.video} />
              </video>
            </div>
          )}
        </>
      )}
    </div>
  );
}

/* STYLES */
const authStyle = {
  container: {
    height: "100vh",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    background: "linear-gradient(135deg,#141414,#000)",
  },
  box: {
    width: 320,
    padding: 25,
    background: "#1f1f1f",
    borderRadius: 12,
    textAlign: "center" as const,
  },
  input: {
    width: "100%",
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    border: "none",
    background: "#333",
    color: "white",
  },
  button: {
    width: "100%",
    padding: 10,
    background: "red",
    color: "white",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
  },
};

const header = {
  display: "flex",
  alignItems: "center",
  padding: 10,
  background: "#000",
};

const grid = {
  display: "grid",
  gridTemplateColumns: "repeat(auto-fill, minmax(180px,1fr))",
  gap: 20,
  padding: 20,
};

const uploadStyle = {
  container: {
    margin: 20,
    padding: 25,
    borderRadius: 12,
    background: "#111",
  },
  title: {
    color: "#fff",
    marginBottom: 10,
  },
  input: {
    width: "100%",
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
  },
  button: {
    width: "100%",
    padding: 10,
    background: "red",
    color: "#fff",
    border: "none",
    borderRadius: 8,
  },
};
const navStyle = {
  display: "flex",
  gap: 10,
  marginLeft: 20,
};

const navBtn = {
  padding: "8px 14px",
  borderRadius: 10,
  border: "none",
  cursor: "pointer",
  fontWeight: "bold",
  transition: "0.2s",
};
const adminModal = {
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(0,0,0,0.85)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
  },
  box: {
    width: 320,
    padding: 25,
    borderRadius: 15,
    background: "#1f1f1f",
    textAlign: "center" as const,
    boxShadow: "0 0 20px rgba(255,0,0,0.4)",
  },
  input: {
    width: "100%",
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
    border: "none",
    background: "#333",
    color: "white",
  },
  loginBtn: {
    width: "100%",
    padding: 10,
    background: "red",
    color: "white",
    border: "none",
    borderRadius: 8,
    marginTop: 5,
  },
  cancelBtn: {
    width: "100%",
    padding: 10,
    background: "#444",
    color: "white",
    border: "none",
    borderRadius: 8,
    marginTop: 8,
  },
};
